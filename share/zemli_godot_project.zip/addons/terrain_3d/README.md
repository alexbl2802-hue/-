![Terrain3D Logo](/doc/docs/images/terrain3d.jpg)

# Terrain3D
A high performance, editable terrain system for Godot 4.


## Features
* Written in C++ as a GDExtension addon, which works with official builds of Godot Engine
* [Can be accessed](https://terrain3d.readthedocs.io/en/stable/docs/programming_languages.html) by GDScript, C#, and any language Godot supports
* Terrains as small as 64x64m up to 65.5x65.5km (4295km^2) in non-contiguous and variable sized regions
* Up to 32 textures
* Up to 10 levels of detail for the terrain mesh
* Foliage instancing, with up to 10 levels of detail, and a shadow impostor
* Sculpting, holes, texture painting, texture detiling, painting colors and wetness
* Imports heightmaps from [HTerrain](https://github.com/Zylann/godot_heightmap_plugin/), Gaea, World Creator, World Machine, Unity, Unreal and any tool that can export a heightmap. See [heightmaps](https://terrain3d.readthedocs.io/en/stable/docs/heightmaps.html)


## Games Using Terrain3D

Please see the [featured games using Terrain3D](https://terrain3d.readthedocs.io/en/latest/docs/games.html) for examples of what it can do.


## Getting Started

1. Read the [Introduction](https://terrain3d.readthedocs.io/en/stable/docs/introduction.html) to understand how this terrain system works.

2. Read the [Installation & Upgrade](https://terrain3d.readthedocs.io/en/stable/docs/installation.html) instructions.

3. Watch the [tutorial videos](https://terrain3d.readthedocs.io/en/stable/docs/tutorial_videos.html) and read through the documentation.

4. For support, read [Getting Help](https://terrain3d.readthedocs.io/en/stable/docs/getting_help.html) and join our [Discord server](https://tokisan.com/discord).


## News & Updates

Announcements are made on these media channels:

||||||
|--|--|--|--|--|
| [Discord](https://tokisan.com/discord) | [X](https://x.com/TokisanGames) | [YouTube](https://www.youtube.com/@TokisanGames) | [Website](https://tokisan.com/) | [Github](https://github.com/TokisanGames) |

See the [Development Roadmap](https://github.com/users/TokisanGames/projects/3) for the priority of pending issues.


## Credit

See the team in [AUTHORS.md](https://terrain3d.readthedocs.io/en/stable/docs/authors.html) and on the right of the github page.


## Contributing

Please see [Contributing](https://terrain3d.readthedocs.io/en/latest/docs/contributing.html) if you would like to help make Terrain3D the best terrain system for Godot.


## License

This addon has been released under the [MIT License](https://github.com/TokisanGames/Terrain3D/blob/main/LICENSE.txt).
